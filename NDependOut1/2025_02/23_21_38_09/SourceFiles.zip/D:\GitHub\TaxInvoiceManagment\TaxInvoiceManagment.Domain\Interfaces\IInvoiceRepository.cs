﻿using TaxInvoiceManagment.Domain.Entities;

namespace TaxInvoiceManagment.Domain.Interfaces
{
    public interface IInvoiceRepository : IBaseRepository<Invoice> { }
}
