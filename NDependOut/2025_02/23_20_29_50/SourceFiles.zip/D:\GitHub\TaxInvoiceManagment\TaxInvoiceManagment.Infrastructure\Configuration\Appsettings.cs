﻿namespace TaxInvoiceManagment.Infrastructure.Configuration
{
    public class Appsettings
    {
    }
}
