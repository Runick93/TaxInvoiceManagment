﻿namespace TaxInvoiceManagment.Infrastructure.Configuration
{
    public static class Appsettings
    {
    }
}